# Seed Launcher

Minimalist Minecraft Java launcher. Offline accounts, instances, Modrinth mods / resource packs / shaders / modpacks,
Fabric & Quilt, themes, local skin server (authlib-injector).

Pure Python 3.9+ standard library (tkinter). No dependencies to run.

## Run
    python seed_launcher.py

## Build exe (Windows)
Put `seed_launcher.py`, `seed.ico`, `icon.png` next to `build.bat` and run `build.bat`.
Result: `dist/Seed Launcher.exe`

Data is stored in `%APPDATA%\.seedlauncher`.
