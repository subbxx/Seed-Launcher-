@echo off
cd /d "%~dp0"

if not exist seed_launcher.py goto nofile
if not exist seed.ico goto nofile
if not exist icon.png goto nofile

set PY=python
where python >nul 2>nul
if errorlevel 1 set PY=py
%PY% --version >nul 2>nul
if errorlevel 1 goto nopython

echo Closing running Seed Launcher if any...
taskkill /f /im "Seed Launcher.exe" >nul 2>nul

echo Installing PyInstaller...
%PY% -m pip install --upgrade pyinstaller
if errorlevel 1 goto fail

echo Building...
%PY% -m PyInstaller --noconfirm --clean --onefile --windowed --name "Seed Launcher" --icon seed.ico --add-data "icon.png;." --add-data "seed.ico;." seed_launcher.py
if errorlevel 1 goto fail

if exist "dist\Seed Launcher.exe" goto ok
echo.
echo [ERROR] Build finished but exe is missing. Antivirus probably deleted it.
echo Check Windows Security - Protection history, add this folder to exclusions, run again.
pause
exit /b 1

:ok
echo.
echo DONE: %cd%\dist\Seed Launcher.exe
explorer dist
pause
exit /b 0

:nofile
echo [ERROR] Put seed_launcher.py, seed.ico and icon.png next to build.bat
pause
exit /b 1

:nopython
echo [ERROR] Python not found. Install from python.org and tick "Add Python to PATH"
pause
exit /b 1

:fail
echo.
echo [ERROR] Build failed, see the error above.
pause
exit /b 1
