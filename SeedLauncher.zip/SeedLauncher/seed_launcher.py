#!/usr/bin/env python3
# Seed Launcher 1.1 — минималистичный лаунчер Minecraft (Java Edition)
# Только стандартная библиотека Python 3.9+.

import os, sys, json, uuid, hashlib, zipfile, shutil, threading, subprocess, shlex
import platform, time, base64, re, traceback, socket, struct
import urllib.request, urllib.parse, urllib.error
import tkinter as tk
from tkinter import ttk, filedialog, messagebox, colorchooser
from tkinter import font as tkfont
from concurrent.futures import ThreadPoolExecutor
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

APP, VER = "Seed Launcher", "1.3.2"
UA = f"SeedLauncher/{VER}"
IS_WIN = os.name == "nt"
OS_NAME = "windows" if IS_WIN else ("osx" if sys.platform == "darwin" else "linux")

ROOT = os.path.join(os.environ.get("APPDATA", os.path.expanduser("~")) if IS_WIN else os.path.expanduser("~"), ".seedlauncher")
LIBS = os.path.join(ROOT, "libraries")
ASSETS = os.path.join(ROOT, "assets")
VERS = os.path.join(ROOT, "versions")
INST = os.path.join(ROOT, "instances")
RUNTIME = os.path.join(ROOT, "runtime")
BACKUPS = os.path.join(ROOT, "backups")
CFG = os.path.join(ROOT, "config.json")
MAN_CACHE = os.path.join(ROOT, "manifest.json")
SKIN = os.path.join(ROOT, "skin.png")
MANIFEST = "https://piston-meta.mojang.com/mc/game/version_manifest_v2.json"
LOADERS = {"Fabric": ("https://meta.fabricmc.net/v2", "fabric-loader-"),
           "Quilt": ("https://meta.quiltmc.org/v3", "quilt-loader-")}

# ───────────────────────── темы ─────────────────────────
#            фон        панель     текст      приглуш.   линии      акцент
THEMES = {
    "Mono":   ("#0a0a0a", "#111111", "#f2f2f2", "#6e6e6e", "#262626", "#f2f2f2"),
    "Paper":  ("#f3f3f1", "#ffffff", "#111111", "#8a8a8a", "#d4d4d0", "#111111"),
    "Void":   ("#07060d", "#100e1a", "#ece8ff", "#6f6a8f", "#25213a", "#8b5cf6"),
    "Matrix": ("#030a05", "#08140b", "#d6ffe0", "#4f8a5f", "#14301b", "#22ff66"),
    "Cyber":  ("#05080c", "#0b121a", "#e6faff", "#5b7b8a", "#172633", "#00e5ff"),
    "Ember":  ("#0c0705", "#17100c", "#ffeee0", "#8a6a55", "#2e1f16", "#ff6a1f"),
    "Rose":   ("#0d0709", "#1a1014", "#ffe8ef", "#8a5f6c", "#301a22", "#ff4d8d"),
    "Ocean":  ("#050a12", "#0b1522", "#e4f0ff", "#5f7a99", "#162a42", "#3b82f6"),
}
BG = PANEL = FG = DIM = LINE = ACC = ACC_TXT = "#000000"
F = FB = FS = FH = ("Consolas", 10)


def lum(h):
    h = h.lstrip("#")
    r, g, b = (int(h[i:i + 2], 16) for i in (0, 2, 4))
    return (0.2126 * r + 0.7152 * g + 0.0722 * b) / 255


def blend(a, b, t):
    a, b = a.lstrip("#"), b.lstrip("#")
    return "#" + "".join("%02x" % round(int(a[i:i + 2], 16) * (1 - t) + int(b[i:i + 2], 16) * t) for i in (0, 2, 4))


def apply_theme(cfg):
    global BG, PANEL, FG, DIM, LINE, ACC, ACC_TXT, F, FB, FS, FH
    t = THEMES.get(cfg.get("theme"), THEMES["Mono"])
    BG, PANEL, FG, DIM, LINE, acc = t
    ACC = cfg.get("accent") or acc
    ACC_TXT = "#000000" if lum(ACC) > 0.55 else "#ffffff"
    fam, sz = cfg.get("font", "Consolas"), int(cfg.get("fsize", 10))
    F, FB, FS, FH = (fam, sz), (fam, sz, "bold"), (fam, max(sz - 1, 8)), (fam, sz + 12, "bold")


def res(name):
    base = getattr(sys, "_MEIPASS", os.path.dirname(os.path.abspath(__file__)))
    return os.path.join(base, name)


# ───────────────────────── сеть / файлы ─────────────────────────
def http_json(url):
    req = urllib.request.Request(url, headers={"User-Agent": UA})
    with urllib.request.urlopen(req, timeout=30) as r:
        return json.loads(r.read().decode("utf-8"))


def download(url, path, force=False):
    if os.path.exists(path) and not force:
        return
    os.makedirs(os.path.dirname(path), exist_ok=True)
    last = None
    for _ in range(3):
        try:
            req = urllib.request.Request(url, headers={"User-Agent": UA})
            with urllib.request.urlopen(req, timeout=60) as r, open(path + ".part", "wb") as f:
                shutil.copyfileobj(r, f)
            os.replace(path + ".part", path)
            return
        except Exception as e:
            last = e
            time.sleep(1)
    raise last


def fetch_all(tasks, cb):
    uniq = {}
    for url, path in tasks:
        if not os.path.exists(path):
            uniq[path] = url
    todo = [(u, p) for p, u in uniq.items()]
    total, done, lock = len(todo), 0, threading.Lock()

    def work(t):
        nonlocal done
        download(*t)
        with lock:
            done += 1
            d = done
        if d % 20 == 0 or d == total:
            cb(d, total)

    if total:
        with ThreadPoolExecutor(16) as ex:
            list(ex.map(work, todo))


def load_cfg():
    try:
        with open(CFG, encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


def save_cfg(c):
    os.makedirs(ROOT, exist_ok=True)
    with open(CFG, "w", encoding="utf-8") as f:
        json.dump(c, f, indent=2, ensure_ascii=False)


def new_id(name):
    return (re.sub(r"[^a-z0-9]+", "-", name.lower()).strip("-") or "inst")[:20] + "-" + uuid.uuid4().hex[:6]


def fmt_time(s):
    h, m = int(s) // 3600, int(s) % 3600 // 60
    return f"{h}ч {m}м" if h else f"{m}м"


def open_path(p):
    os.makedirs(p, exist_ok=True)
    try:
        if IS_WIN:
            os.startfile(p)
        elif sys.platform == "darwin":
            subprocess.Popen(["open", p])
        else:
            subprocess.Popen(["xdg-open", p])
    except Exception:
        pass


# ───────────────────────── логика Minecraft ─────────────────────────
def offline_uuid(name):
    h = bytearray(hashlib.md5(("OfflinePlayer:" + name).encode()).digest())
    h[6] = (h[6] & 0x0F) | 0x30
    h[8] = (h[8] & 0x3F) | 0x80
    return str(uuid.UUID(bytes=bytes(h)))


def maven_path(name):
    p = name.split(":")
    g, a, v = p[0], p[1], p[2]
    cls = p[3] if len(p) > 3 else None
    return f"{g.replace('.', '/')}/{a}/{v}/{a}-{v}" + (f"-{cls}" if cls else "") + ".jar"


def cur_arch():
    m = platform.machine().lower()
    if "arm" in m or "aarch" in m:
        return "arm64"
    return "x86_64" if "64" in m else "x86"


def rules_ok(rules):
    if not rules:
        return True
    allowed = False
    for r in rules:
        match = True
        if "os" in r:
            o = r["os"]
            if "name" in o and o["name"] != OS_NAME:
                match = False
            if "arch" in o and o["arch"] != cur_arch():
                match = False
        if "features" in r:
            match = False
        if match:
            allowed = r["action"] == "allow"
    return allowed


def merge(parent, child):
    r = dict(parent)
    for k, val in child.items():
        if k == "libraries":
            r[k] = val + parent.get("libraries", [])
        elif k == "arguments":
            pa = parent.get("arguments", {})
            r[k] = {"game": list(pa.get("game", [])) + val.get("game", []),
                    "jvm": list(pa.get("jvm", [])) + val.get("jvm", [])}
        else:
            r[k] = val
    return r


_manifest_mem = {}


def load_version(vid):
    p = os.path.join(VERS, vid, vid + ".json")
    if not os.path.exists(p):
        if not _manifest_mem:
            _manifest_mem.update(http_json(MANIFEST))
        ent = next(v for v in _manifest_mem["versions"] if v["id"] == vid)
        download(ent["url"], p)
    with open(p, encoding="utf-8") as f:
        v = json.load(f)
    if "inheritsFrom" in v:
        parent = load_version(v["inheritsFrom"])
        v = merge(parent, v)
        v["_jar_id"] = parent["_jar_id"]
    else:
        v["_jar_id"] = v["id"]
    return v


def install_loader(mc, loader):
    base, prefix = LOADERS[loader]
    try:
        loaders = http_json(f"{base}/versions/loader/{mc}")
        if not loaders:
            raise RuntimeError(f"{loader} пока не поддерживает {mc}")
        good = [l for l in loaders if l["loader"].get("stable", "-" not in l["loader"]["version"])]
        lv = (good or loaders)[0]["loader"]["version"]
        prof = http_json(f"{base}/versions/loader/{mc}/{lv}/profile/json")
        vid = prof["id"]
        os.makedirs(os.path.join(VERS, vid), exist_ok=True)
        with open(os.path.join(VERS, vid, vid + ".json"), "w", encoding="utf-8") as f:
            json.dump(prof, f)
        return vid
    except urllib.error.URLError:
        if os.path.isdir(VERS):
            for d in sorted(os.listdir(VERS), reverse=True):
                if d.startswith(prefix) and d.endswith("-" + mc):
                    return d
        raise


def find_java(d):
    for r, _, fs in os.walk(d):
        if "java.exe" in fs and r.endswith("bin"):
            return os.path.join(r, "java.exe")
    return None


def ensure_java(major, custom, status):
    if custom and os.path.exists(custom):
        return custom
    if IS_WIN:
        d = os.path.join(RUNTIME, f"java{major}")
        exe = find_java(d) if os.path.isdir(d) else None
        if exe:
            return exe
        status(f"Загрузка Java {major}…")
        url = f"https://api.adoptium.net/v3/binary/latest/{major}/ga/windows/x64/jre/hotspot/normal/eclipse"
        zp = d + ".zip"
        download(url, zp, force=True)
        with zipfile.ZipFile(zp) as z:
            z.extractall(d)
        os.remove(zp)
        exe = find_java(d)
        if exe:
            return exe
        raise RuntimeError("Не удалось установить Java")
    j = shutil.which("java")
    if not j:
        raise RuntimeError("Java не найдена. Установи JDK/JRE или укажи путь в настройках.")
    return j


def prepare(v, gamedir, progress):
    jar_id = v["_jar_id"]
    jar = os.path.join(VERS, jar_id, jar_id + ".jar")
    tasks, cp, natives = [], [], []
    for lib in v["libraries"]:
        if not rules_ok(lib.get("rules")):
            continue
        dl = lib.get("downloads")
        if dl:
            art = dl.get("artifact")
            if art and art.get("url"):
                p = os.path.join(LIBS, art["path"])
                tasks.append((art["url"], p))
                cp.append(p)
            nat = lib.get("natives")
            if nat and OS_NAME in nat:
                cls = nat[OS_NAME].replace("${arch}", "64")
                a = dl.get("classifiers", {}).get(cls)
                if a:
                    p = os.path.join(LIBS, a["path"])
                    tasks.append((a["url"], p))
                    natives.append(p)
        else:
            base = lib.get("url", "https://libraries.minecraft.net/")
            rel = maven_path(lib["name"])
            p = os.path.join(LIBS, rel)
            tasks.append((base + rel, p))
            cp.append(p)
    tasks.append((v["downloads"]["client"]["url"], jar))

    ai = v["assetIndex"]
    idx_path = os.path.join(ASSETS, "indexes", ai["id"] + ".json")
    download(ai["url"], idx_path)
    with open(idx_path, encoding="utf-8") as f:
        idx = json.load(f)
    for name, o in idx["objects"].items():
        h = o["hash"]
        tasks.append((f"https://resources.download.minecraft.net/{h[:2]}/{h}",
                      os.path.join(ASSETS, "objects", h[:2], h)))
    fetch_all(tasks, progress)

    assets_dir = ASSETS
    if idx.get("virtual") or idx.get("map_to_resources"):
        dest = os.path.join(ASSETS, "virtual", "legacy") if idx.get("virtual") else os.path.join(gamedir, "resources")
        for name, o in idx["objects"].items():
            t = os.path.join(dest, *name.split("/"))
            if not os.path.exists(t):
                os.makedirs(os.path.dirname(t), exist_ok=True)
                shutil.copyfile(os.path.join(ASSETS, "objects", o["hash"][:2], o["hash"]), t)
        if idx.get("virtual"):
            assets_dir = dest

    nd = os.path.join(VERS, v["id"], "natives")
    os.makedirs(nd, exist_ok=True)
    for n in natives:
        with zipfile.ZipFile(n) as z:
            for m in z.namelist():
                if m.startswith("META-INF") or m.endswith("/"):
                    continue
                z.extract(m, nd)

    seen, uniq = set(), []
    for c in cp:
        if c not in seen:
            seen.add(c)
            uniq.append(c)
    return uniq + [jar], nd, assets_dir


def build_cmd(v, java, gamedir, nick, inst, cp, nd, assets_dir, agent=()):
    subs = {
        "auth_player_name": nick, "version_name": v["id"], "game_directory": gamedir,
        "assets_root": assets_dir, "game_assets": assets_dir, "assets_index_name": v["assetIndex"]["id"],
        "auth_uuid": offline_uuid(nick), "auth_access_token": "0", "auth_session": "0",
        "user_type": "legacy", "version_type": "SeedLauncher", "natives_directory": nd,
        "launcher_name": "SeedLauncher", "launcher_version": VER, "classpath": os.pathsep.join(cp),
        "library_directory": LIBS, "classpath_separator": os.pathsep, "user_properties": "{}",
        "clientid": "", "auth_xuid": "", "resolution_width": "854", "resolution_height": "480",
    }

    def sub(s):
        for k, val in subs.items():
            s = s.replace("${" + k + "}", val)
        return s

    def flat(args):
        out = []
        for a in args:
            if isinstance(a, str):
                out.append(sub(a))
            elif rules_ok(a.get("rules")):
                val = a["value"]
                out += [sub(x) for x in ([val] if isinstance(val, str) else val)]
        return out

    if "arguments" in v:
        jvm, game = flat(v["arguments"].get("jvm", [])), flat(v["arguments"]["game"])
    else:
        jvm = ["-Djava.library.path=" + nd, "-cp", os.pathsep.join(cp)]
        game = [sub(x) for x in v["minecraftArguments"].split()]

    extra_jvm = shlex.split(inst.get("jvm", "") or "", posix=not IS_WIN)
    extra_game = []
    if int(inst.get("w", 0) or 0) > 0 and int(inst.get("h", 0) or 0) > 0:
        extra_game += ["--width", str(inst["w"]), "--height", str(inst["h"])]
    if inst.get("fs"):
        extra_game += ["--fullscreen"]
    srv = (inst.get("server") or "").strip()
    if srv:
        if "has_quick_plays_support" in json.dumps(v.get("arguments", {})):
            extra_game += ["--quickPlayMultiplayer", srv]
        else:
            host, _, port = srv.partition(":")
            extra_game += ["--server", host, "--port", port or "25565"]
    return [java, f"-Xmx{inst.get('ram', 4096)}M", "-Xms512M"] + list(agent) + extra_jvm + jvm + [v["mainClass"]] + game + extra_game


# ───────────────────────── скины ─────────────────────────
SKIN_NAMES = ["steve", "ari", "efe", "kai", "makena", "noor", "sunny", "zuri", "alex"]


def enable_pack(gamedir, pack):
    p = os.path.join(gamedir, "options.txt")
    lines = []
    if os.path.exists(p):
        with open(p, encoding="utf-8") as f:
            lines = f.read().splitlines()
    found = False
    for i, l in enumerate(lines):
        if l.startswith("resourcePacks:"):
            try:
                lst = json.loads(l.split(":", 1)[1])
            except Exception:
                lst = ["vanilla"]
            if pack not in lst:
                lst.append(pack)
            lines[i] = "resourcePacks:" + json.dumps(lst, separators=(",", ":"))
            found = True
    if not found:
        lines.append("resourcePacks:" + json.dumps(["vanilla", pack], separators=(",", ":")))
    os.makedirs(gamedir, exist_ok=True)
    with open(p, "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n")


def remove_skin_pack(gamedir):
    rp = os.path.join(gamedir, "resourcepacks", "seed_skin.zip")
    if os.path.exists(rp):
        os.remove(rp)
    p = os.path.join(gamedir, "options.txt")
    if os.path.exists(p):
        with open(p, encoding="utf-8") as f:
            lines = f.read().splitlines()
        for i, l in enumerate(lines):
            if l.startswith("resourcePacks:") and "seed_skin.zip" in l:
                try:
                    lst = [x for x in json.loads(l.split(":", 1)[1]) if x != "file/seed_skin.zip"]
                    lines[i] = "resourcePacks:" + json.dumps(lst, separators=(",", ":"))
                except Exception:
                    pass
        with open(p, "w", encoding="utf-8") as f:
            f.write("\n".join(lines) + "\n")


def apply_skin(gamedir):
    """Запасной способ: скин ресурспаком."""
    rp = os.path.join(gamedir, "resourcepacks", "seed_skin.zip")
    if not os.path.exists(SKIN):
        remove_skin_pack(gamedir)
        return
    os.makedirs(os.path.dirname(rp), exist_ok=True)
    with open(SKIN, "rb") as f:
        data = f.read()
    meta = {"pack": {"pack_format": 15, "description": "Seed Launcher skin",
                     "supported_formats": {"min_inclusive": 1, "max_inclusive": 999}}}
    with zipfile.ZipFile(rp, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("pack.mcmeta", json.dumps(meta))
        for n in ("steve", "alex"):
            z.writestr(f"assets/minecraft/textures/entity/{n}.png", data)
        for n in SKIN_NAMES:
            for t in ("wide", "slim"):
                z.writestr(f"assets/minecraft/textures/entity/player/{t}/{n}.png", data)
    enable_pack(gamedir, "file/seed_skin.zip")


SKIN_N = 0xcf4b99d7c754f921a8ecdbbc9731ba3f08adeb134e282650c52826965bf37aade45511b78c0cf7021b084d3c7999d95645e4950cb4ac3a61fa01843355b427ccab1609b2841b04aad67a07f763968ccb06b52b489b9a682b7d72efe3a934b357dd859b54549cfc3b083e9d9ee6a791540830f16fd4118b1a42dde70c2e2ed48e801bd5e7511094b727e24cee850c2cf73a1806e7a58cdee54e4e4fc7566cf670df1267f93528dcdb425618459a5e017035726933ed595e13dc13876b78087a8f4208c91f5982d379d31a780c093ac25df8a2d7f03eb5ad76f0c25bccb46dfce65fe266afa4fa11ce5c2b1173314f79e4c691c4f94b29a2ab4e13b8186aa574fd
SKIN_D = 0x13ff24fe0dba82b5de87cac2ac8b1d7e4b260bd136eee4935211877765b35d183d387f970729910260fd32062d6ccbec689d9e4b357a8fbf37d0c1a1fa1880e65b72aac8cfb9937faf64e233d92582bb6b103af6ac1bff0482fb7d6ca6bbf0b8ff238e525a3f328db743e30c9b0f7b13721ed68b851794259a61b192193a674293451eb4287c03b256f31fd522bbe680b66404323caf7cbcfa5d25501fa7c5d129df05b2079f31b54c8b91bcc6f95bc816ec6744138075908c68268402c2f954b93e5b4b287037c52ce3715801198f1cce8308509844ec89767d7e18f84de66995ce393de69715c9b1a21e051add3003796a298d8377a8effdf401fd507032c1
SKIN_PUB = """-----BEGIN PUBLIC KEY-----
MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAz0uZ18dU+SGo7Nu8lzG6
Pwit6xNOKCZQxSgmllvzeq3kVRG3jAz3AhsITTx5mdlWReSVDLSsOmH6AYQzVbQn
zKsWCbKEGwSq1noH92OWjMsGtStIm5poK31y7+OpNLNX3YWbVFSc/DsIPp2e5qeR
VAgw8W/UEYsaQt3nDC4u1I6AG9XnURCUtyfiTO6FDCz3OhgG56WM3uVOTk/HVmz2
cN8SZ/k1KNzbQlYYRZpeAXA1cmkz7VleE9wTh2t4CHqPQgjJH1mC03nTGngMCTrC
Xfii1/A+ta128MJbzLRt/OZf4mavpPoRzlwrEXMxT3nkxpHE+UspoqtOE7gYaqV0
/QIDAQAB
-----END PUBLIC KEY-----
"""


def rsa_sign_sha1(msg):
    digest = hashlib.sha1(msg).digest()
    t = bytes.fromhex("3021300906052b0e03021a05000414") + digest
    k = (SKIN_N.bit_length() + 7) // 8
    em = b"\x00\x01" + b"\xff" * (k - len(t) - 3) + b"\x00" + t
    return base64.b64encode(pow(int.from_bytes(em, "big"), SKIN_D, SKIN_N).to_bytes(k, "big")).decode()


class SkinServer:
    """Локальный Yggdrasil-сервер: отдаёт игре твой скин (через authlib-injector). Без ресурспаков."""

    def __init__(self, png, nick, slim):
        self.png, self.slim, self.nick = png, slim, nick
        self.hash = hashlib.sha256(png).hexdigest()
        self.uid = offline_uuid(nick).replace("-", "")
        outer = self

        class H(BaseHTTPRequestHandler):
            def log_message(self, *a):
                pass

            def send(self, code, body=b"", ctype="application/json"):
                self.send_response(code)
                self.send_header("Content-Type", ctype)
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                if body:
                    self.wfile.write(body)

            def do_GET(self):
                path = self.path.split("?")[0]
                if path in ("", "/"):
                    meta = {"meta": {"serverName": "Seed Launcher", "implementationName": "seed-launcher",
                                     "implementationVersion": VER},
                            "skinDomains": ["127.0.0.1", "localhost"], "signaturePublickey": SKIN_PUB}
                    self.send(200, json.dumps(meta).encode())
                elif path.startswith("/textures/"):
                    self.send(200, outer.png, "image/png")
                elif path.startswith("/sessionserver/session/minecraft/profile/"):
                    if path.rsplit("/", 1)[1].replace("-", "") == outer.uid:
                        self.send(200, json.dumps(outer.profile()).encode())
                    else:
                        self.send(204)
                else:
                    self.send(404)

            def do_POST(self):
                n = int(self.headers.get("Content-Length") or 0)
                if n:
                    self.rfile.read(n)
                self.send(204 if "/session/minecraft/join" in self.path else 404)

        self.httpd = ThreadingHTTPServer(("127.0.0.1", 0), H)
        self.port = self.httpd.server_address[1]
        threading.Thread(target=self.httpd.serve_forever, daemon=True).start()

    def profile(self):
        skin = {"url": f"http://127.0.0.1:{self.port}/textures/{self.hash}"}
        if self.slim:
            skin["metadata"] = {"model": "slim"}
        tex = {"timestamp": int(time.time() * 1000), "profileId": self.uid, "profileName": self.nick,
               "textures": {"SKIN": skin}}
        val = base64.b64encode(json.dumps(tex).encode()).decode()
        return {"id": self.uid, "name": self.nick,
                "properties": [{"name": "textures", "value": val, "signature": rsa_sign_sha1(val.encode())}]}

    def stop(self):
        try:
            self.httpd.shutdown()
        except Exception:
            pass


def ensure_injector():
    p = os.path.join(ROOT, "authlib-injector.jar")
    if os.path.exists(p):
        return p
    for api in ("https://authlib-injector.yushi.moe/artifact/latest.json",
                "https://bmclapi2.bangbang93.com/mirrors/authlib-injector/artifact/latest.json"):
        try:
            download(http_json(api)["download_url"], p)
            return p
        except Exception:
            continue
    return None


def fetch_skin_by_nick(name):
    try:
        d = http_json("https://api.mojang.com/users/profiles/minecraft/" + urllib.parse.quote(name))
    except urllib.error.HTTPError:
        raise RuntimeError("Игрок с таким ником не найден")
    prof = http_json("https://sessionserver.mojang.com/session/minecraft/profile/" + d["id"])
    for p in prof.get("properties", []):
        if p["name"] == "textures":
            tex = json.loads(base64.b64decode(p["value"]))
            download(tex["textures"]["SKIN"]["url"], SKIN, force=True)
            return
    raise RuntimeError("У игрока нет скина")


def png_size(path):
    with open(path, "rb") as f:
        h = f.read(24)
    if h[:8] != b"\x89PNG\r\n\x1a\n":
        raise ValueError("Это не PNG")
    return int.from_bytes(h[16:20], "big"), int.from_bytes(h[20:24], "big")


# ───────────────────────── Modrinth ─────────────────────────
def loaders_for(loader):
    return ["quilt", "fabric"] if loader == "Quilt" else [loader.lower()]


def mr_search(q, ptype, mc, loader):
    facets = [[f"project_type:{ptype}"]]
    if ptype != "modpack":
        facets.append([f"versions:{mc}"])
    if ptype == "mod":
        facets.append([f"categories:{l}" for l in loaders_for(loader)])
    qs = urllib.parse.urlencode({"query": q, "facets": json.dumps(facets), "limit": 40,
                                 "index": "relevance" if q else "downloads"})
    return http_json("https://api.modrinth.com/v2/search?" + qs)["hits"]


def vkey(v):
    vn = re.sub(r"(?i)[+\-_ ]?mc[\d.]+", "", v.get("version_number", ""))
    m = re.search(r"\d+(?:\.\d+)*", vn)
    return tuple(int(x) for x in m.group(0).split(".")) if m else (0,)


def _vt(s):
    m = re.match(r"\d+(?:\.\d+)*", s.strip())
    return tuple(int(x) for x in m.group(0).split(".")) if m else None


def ver_ok(constraint, ver):
    """Проверка версии Minecraft по условию из fabric.mod.json (>=26.1 <26.2, ~26.1, 26.1.x, 26.1.2 ...)."""
    v = _vt(ver)
    if v is None:
        return True
    for alt in (constraint if isinstance(constraint, list) else [constraint]):
        ok = True
        for tok in str(alt).split():
            if tok in ("*", ""):
                continue
            m = re.match(r"(>=|<=|>|<|=|~|\^)?(.*)", tok)
            op, val = m.group(1) or "=", m.group(2)
            if re.search(r"[xX*]", val):
                t = tuple(int(p) for p in val.split(".") if p.isdigit())
                ok = ok and v[:len(t)] == t
                continue
            t = _vt(val)
            if t is None:
                continue
            n = max(len(v), len(t))
            a, b = v + (0,) * (n - len(v)), t + (0,) * (n - len(t))
            k = min(len(t), 2)
            ok = ok and {"=": a == b, ">=": a >= b, "<=": a <= b, ">": a > b, "<": a < b,
                         "~": a >= b and a[:k] == b[:k], "^": a >= b and a[0] == b[0]}[op]
        if ok:
            return True
    return False


def mod_mc_ok(path, mc):
    try:
        with zipfile.ZipFile(path) as z:
            j = json.loads(z.read("fabric.mod.json").decode("utf-8-sig"))
        dep = j.get("depends", {}).get("minecraft")
        return (True if dep is None else ver_ok(dep, mc)), dep
    except Exception:
        return True, None


def mr_install(pid, kind, mc, loader, folder, seen, pin=None):
    if pid in seen:
        return
    seen.add(pid)
    if pin:
        cands = [http_json(f"https://api.modrinth.com/v2/version/{pin}")]
    else:
        params = {"game_versions": json.dumps([mc])}
        if kind == "mod":
            params["loaders"] = json.dumps(loaders_for(loader))
        vs = http_json(f"https://api.modrinth.com/v2/project/{pid}/version?" + urllib.parse.urlencode(params))
        if not vs:
            raise RuntimeError(f"Нет подходящей версии для {mc}")
        key = lambda x: (vkey(x), x.get("date_published", ""))
        cands = sorted([x for x in vs if x.get("version_type") != "alpha"], key=key, reverse=True) + \
            sorted([x for x in vs if x.get("version_type") == "alpha"], key=key, reverse=True)
    v, need = None, None
    for cand in cands[:8]:
        f = next((x for x in cand["files"] if x.get("primary")), cand["files"][0])
        path = os.path.join(folder, f["filename"])
        existed = os.path.exists(path)
        download(f["url"], path)
        if kind != "mod" or pin:
            v = cand
            break
        ok, dep = mod_mc_ok(path, mc)
        if ok:
            v = cand
            break
        need = need or dep
        if not existed:
            os.remove(path)
    if v is None:
        raise RuntimeError(f"Мод требует Minecraft {need}, а у сборки {mc}. Смени версию сборки")
    f = next((x for x in v["files"] if x.get("primary")), v["files"][0])
    mp = os.path.join(folder, ".seed_installed.json")
    try:
        with open(mp, encoding="utf-8") as fh:
            reg = json.load(fh)
    except Exception:
        reg = {}
    old = reg.get(pid)
    if old and old != f["filename"] and os.path.exists(os.path.join(folder, old)):
        os.remove(os.path.join(folder, old))
    reg[pid] = f["filename"]
    with open(mp, "w", encoding="utf-8") as fh:
        json.dump(reg, fh)
    if kind == "mod":
        for d in v.get("dependencies", []):
            if d.get("dependency_type") == "required" and d.get("project_id"):
                mr_install(d["project_id"], kind, mc, loader, folder, seen, d.get("version_id"))


def install_mrpack(path, name, progress):
    with zipfile.ZipFile(path) as z:
        idx = json.loads(z.read("modrinth.index.json"))
        deps = idx.get("dependencies", {})
        mc = deps["minecraft"]
        if "fabric-loader" in deps:
            loader = "Fabric"
        elif "quilt-loader" in deps:
            loader = "Quilt"
        elif "forge" in deps or "neoforge" in deps:
            raise RuntimeError("Модпак для Forge/NeoForge — пока не поддерживается")
        else:
            loader = "Vanilla"
        iid = new_id(idx.get("name") or name)
        d = os.path.normpath(os.path.join(INST, iid))
        tasks = []
        for f in idx.get("files", []):
            if f.get("env", {}).get("client") == "unsupported":
                continue
            t = os.path.normpath(os.path.join(d, *f["path"].split("/")))
            if t.startswith(d):
                tasks.append((f["downloads"][0], t))
        fetch_all(tasks, progress)
        for n in z.namelist():
            for pre in ("overrides/", "client-overrides/"):
                if n.startswith(pre) and not n.endswith("/"):
                    t = os.path.normpath(os.path.join(d, n[len(pre):]))
                    if t.startswith(d):
                        os.makedirs(os.path.dirname(t), exist_ok=True)
                        with z.open(n) as s, open(t, "wb") as o:
                            shutil.copyfileobj(s, o)
    return {"name": idx.get("name") or name, "mc": mc, "loader": loader, "dir": iid}



# ───────────────────────── пинг серверов ─────────────────────────
def _varint(n):
    out = b""
    while True:
        b = n & 0x7F
        n >>= 7
        out += bytes([b | (0x80 if n else 0)])
        if not n:
            return out


def _recv(sock, n):
    buf = b""
    while len(buf) < n:
        chunk = sock.recv(n - len(buf))
        if not chunk:
            raise ConnectionError("closed")
        buf += chunk
    return buf


def _read_varint(sock):
    num = 0
    for i in range(5):
        b = _recv(sock, 1)[0]
        num |= (b & 0x7F) << (7 * i)
        if not b & 0x80:
            return num
    raise ValueError("varint")


def _dns_name(r, i):
    parts, jumped, nxt = [], False, i
    while True:
        ln = r[i]
        if ln == 0:
            i += 1
            break
        if ln & 0xC0 == 0xC0:
            if not jumped:
                nxt = i + 2
            i, jumped = ((ln & 0x3F) << 8) | r[i + 1], True
            continue
        parts.append(r[i + 1:i + 1 + ln].decode())
        i += ln + 1
    return ".".join(parts), (nxt if jumped else i)


def srv_lookup(host):
    """SRV-запись _minecraft._tcp (как делает сама игра). Возвращает (host, port) или None."""
    try:
        q = struct.pack(">HHHHHH", 0x1234, 0x0100, 1, 0, 0, 0)
        for part in ("_minecraft._tcp." + host).split("."):
            q += bytes([len(part)]) + part.encode()
        q += b"\x00" + struct.pack(">HH", 33, 1)
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.settimeout(2)
        s.sendto(q, ("1.1.1.1", 53))
        r, _ = s.recvfrom(2048)
        s.close()
        if struct.unpack(">H", r[6:8])[0] == 0:
            return None
        i = 12
        _, i = _dns_name(r, i)
        i += 4
        _, i = _dns_name(r, i)
        rtype, _, _, _ = struct.unpack(">HHIH", r[i:i + 10])
        i += 10
        if rtype != 33:
            return None
        port = struct.unpack(">H", r[i + 4:i + 6])[0]
        name, _ = _dns_name(r, i + 6)
        return name, port
    except Exception:
        return None


def _motd(d):
    if isinstance(d, str):
        return d
    if isinstance(d, list):
        return "".join(_motd(x) for x in d)
    if isinstance(d, dict):
        return d.get("text", "") + "".join(_motd(x) for x in d.get("extra", []))
    return ""


def ping_server(addr, timeout=4):
    host, _, port = addr.partition(":")
    port = int(port) if port else 25565
    if not _:
        srv = srv_lookup(host)
        if srv:
            host_conn, port = srv
        else:
            host_conn = host
    else:
        host_conn = host
    with socket.create_connection((host_conn, port), timeout) as s:
        s.settimeout(timeout)
        hb = host.encode()
        data = b"\x00" + _varint(767) + _varint(len(hb)) + hb + struct.pack(">H", port) + _varint(1)
        s.sendall(_varint(len(data)) + data + b"\x01\x00")
        t0 = time.time()
        _read_varint(s)
        _read_varint(s)
        ln = _read_varint(s)
        raw = _recv(s, ln)
        ms = int((time.time() - t0) * 1000)
    j = json.loads(raw.decode("utf-8", "replace"))
    motd = re.sub(r"§.", "", _motd(j.get("description", ""))).replace("\n", " ").strip()
    pl = j.get("players", {})
    return motd, pl.get("online", 0), pl.get("max", 0), j.get("version", {}).get("name", "?"), ms


# ───────────────────────── виджеты ─────────────────────────
def dark_title(w):
    if not IS_WIN:
        return
    try:
        import ctypes
        w.update_idletasks()
        hwnd = ctypes.windll.user32.GetParent(w.winfo_id())
        v = ctypes.c_int(1 if lum(BG) < 0.5 else 0)
        for attr in (20, 19):
            ctypes.windll.dwmapi.DwmSetWindowAttribute(hwnd, attr, ctypes.byref(v), 4)
    except Exception:
        pass


def mkbtn(parent, text, cmd, primary=False, **kw):
    px, py = kw.pop("padx", 16), kw.pop("pady", 7)
    if primary:
        b = tk.Button(parent, text=text, command=cmd, font=FB, bd=0, relief="flat", cursor="hand2", bg=ACC, fg=ACC_TXT,
                      activebackground=blend(ACC, FG, .3), activeforeground=ACC_TXT, highlightthickness=0,
                      padx=px, pady=py, **kw)
        b.bind("<Enter>", lambda e: b.config(bg=blend(ACC, FG, .2)) if str(b["state"]) == "normal" else None)
        b.bind("<Leave>", lambda e: b.config(bg=ACC))
    else:
        b = tk.Button(parent, text=text, command=cmd, font=FB, bd=0, relief="flat", cursor="hand2", bg=BG, fg=FG,
                      activebackground=BG, activeforeground=ACC, highlightthickness=1, highlightbackground=LINE,
                      highlightcolor=ACC, padx=px, pady=py, **kw)
        b.bind("<Enter>", lambda e: b.config(highlightbackground=ACC, fg=ACC))
        b.bind("<Leave>", lambda e: b.config(highlightbackground=LINE, fg=FG))
    return b


def mkentry(parent, var, width=22):
    return tk.Entry(parent, textvariable=var, width=width, font=F, bg=PANEL, fg=FG, insertbackground=ACC,
                    relief="flat", highlightthickness=1, highlightbackground=LINE, highlightcolor=ACC)


def mklabel(parent, text, dim=False, font=None):
    return tk.Label(parent, text=text, font=font or F, bg=BG, fg=DIM if dim else FG, anchor="w")


def mklist(parent, height=8):
    return tk.Listbox(parent, height=height, font=F, bg=PANEL, fg=FG, bd=0, relief="flat",
                      selectbackground=ACC, selectforeground=ACC_TXT, activestyle="none",
                      highlightthickness=1, highlightbackground=LINE, highlightcolor=ACC)


def mkcheck(parent, text, var, cmd=None):
    return tk.Checkbutton(parent, text=text, variable=var, command=cmd, font=FS, bg=BG, fg=FG, selectcolor=PANEL,
                          activebackground=BG, activeforeground=ACC, bd=0, highlightthickness=0)


def header(parent, title, sub):
    tk.Label(parent, text=title, font=FH, bg=BG, fg=FG, anchor="w").pack(fill="x")
    tk.Label(parent, text=sub, font=FS, bg=BG, fg=DIM, anchor="w").pack(fill="x", pady=(2, 0))
    tk.Frame(parent, bg=ACC, height=2).pack(fill="x", pady=(14, 0))


def draw_logo(cv, size, color):
    s = size / 60.0
    polys = [[(30.1, .4), (52.3, 12.2), (30.1, 25.2), (7.9, 12.2)],
             [(2.3, 17.4), (26.8, 30.4), (26.8, 59.6), (2.3, 43.5)],
             [(57.7, 17.4), (33.5, 30.4), (33.5, 59.6), (57.7, 43.5)]]
    for p in polys:
        cv.create_polygon([c * s for pt in p for c in pt], fill=color, outline=color, width=1, joinstyle="round")


class ContentPage(tk.Frame):
    """Моды / ресурспаки / шейдеры / модпаки."""

    def __init__(self, app, parent, kind, ptype, folder, title, sub):
        super().__init__(parent, bg=BG, padx=36, pady=28)
        self.app, self.kind, self.ptype, self.folder = app, kind, ptype, folder
        self.hits, self.is_pack = [], kind == "modpack"
        header(self, title, sub)
        bar = tk.Frame(self, bg=BG)
        bar.pack(fill="x", pady=(16, 8))
        self.q = tk.StringVar()
        e = mkentry(bar, self.q, 40)
        e.pack(side="left", ipady=5)
        e.bind("<Return>", lambda ev: self.search())
        mkbtn(bar, "ПОИСК", self.search).pack(side="left", padx=8)
        self.msg = tk.StringVar(value="")
        tk.Label(bar, textvariable=self.msg, font=FS, bg=BG, fg=DIM).pack(side="right")
        self.res = mklist(self, 12 if self.is_pack else 9)
        self.res.pack(fill="both", expand=True)
        row = tk.Frame(self, bg=BG)
        row.pack(fill="x", pady=8)
        if self.is_pack:
            mkbtn(row, "УСТАНОВИТЬ КАК СБОРКУ", self.install_pack, primary=True).pack(side="left")
            mkbtn(row, "ИМПОРТ .MRPACK…", self.import_pack).pack(side="left", padx=8)
            return
        mkbtn(row, "УСТАНОВИТЬ", self.install, primary=True).pack(side="left")
        mkbtn(row, "ДОБАВИТЬ ФАЙЛ…", self.add_file).pack(side="left", padx=8)
        mklabel(self, "УСТАНОВЛЕНО", dim=True, font=FS).pack(fill="x", pady=(8, 4))
        self.inst = mklist(self, 5)
        self.inst.pack(fill="x")
        row2 = tk.Frame(self, bg=BG)
        row2.pack(fill="x", pady=8)
        mkbtn(row2, "УДАЛИТЬ", self.remove).pack(side="left")
        mkbtn(row2, "ОТКРЫТЬ ПАПКУ", lambda: open_path(self.dir())).pack(side="left", padx=8)

    def dir(self):
        return os.path.join(self.app.profile()[2], self.folder)

    def on_show(self):
        if not self.is_pack:
            self.refresh_installed()
        if not self.hits:
            self.search()

    def refresh_installed(self):
        self.inst.delete(0, "end")
        d = self.dir()
        if os.path.isdir(d):
            for f in sorted(os.listdir(d)):
                if f.lower().endswith((".jar", ".zip")) and f != "seed_skin.zip":
                    self.inst.insert("end", f)

    def search(self):
        mc, loader, _ = self.app.profile()
        if self.kind == "mod" and loader == "Vanilla":
            self.msg.set("У этой сборки загрузчик Vanilla — смени на Fabric (СБОРКИ)")
            return
        self.msg.set("поиск…")

        def work():
            try:
                hits = mr_search(self.q.get().strip(), self.ptype, mc, loader)
                self.app.ui(self.show_hits, hits)
            except Exception as e:
                self.app.ui(self.msg.set, "Ошибка сети: " + str(e)[:50])
        threading.Thread(target=work, daemon=True).start()

    def show_hits(self, hits):
        self.hits = hits
        self.res.delete(0, "end")
        for h in hits:
            self.res.insert("end", f"{h['title'][:34]:<36}{h['author'][:16]:<18}↓{h['downloads']:,}".replace(",", " "))
        self.msg.set(f"найдено: {len(hits)}")

    def install(self):
        sel = self.res.curselection()
        if not sel:
            return
        h = self.hits[sel[0]]
        mc, loader, _ = self.app.profile()
        self.msg.set("установка…")

        def work():
            try:
                mr_install(h["project_id"], self.kind, mc, loader, self.dir(), set())
                self.app.ui(self.msg.set, "установлено: " + h["title"])
                self.app.ui(self.refresh_installed)
            except Exception as e:
                self.app.ui(self.msg.set, "Ошибка: " + str(e)[:50])
        threading.Thread(target=work, daemon=True).start()

    def add_file(self):
        files = filedialog.askopenfilenames(filetypes=[("Файлы", "*.jar *.zip"), ("Все", "*.*")])
        if files:
            os.makedirs(self.dir(), exist_ok=True)
            for f in files:
                shutil.copy(f, self.dir())
            self.refresh_installed()
            self.msg.set("добавлено файлов: %d" % len(files))

    def remove(self):
        sel = self.inst.curselection()
        if sel:
            try:
                os.remove(os.path.join(self.dir(), self.inst.get(sel[0])))
            except OSError as e:
                self.msg.set(str(e)[:50])
            self.refresh_installed()

    # модпаки
    def _pack_job(self, getter, label):
        self.msg.set("скачивание и установка…")

        def work():
            try:
                path, tmp = getter()
                inst = install_mrpack(path, label, lambda d, t: self.app.ui(self.app.set_prog, d, t))
                if tmp:
                    os.remove(path)
                self.app.ui(self.app.add_instance, inst)
                self.app.ui(self.msg.set, "готово — добавлена сборка: " + inst["name"])
                self.app.ui(self.app.prog.config, {"value": 0})
            except Exception as e:
                self.app.ui(self.msg.set, "Ошибка: " + str(e)[:60])
        threading.Thread(target=work, daemon=True).start()

    def install_pack(self):
        sel = self.res.curselection()
        if not sel:
            return
        h = self.hits[sel[0]]

        def getter():
            vs = http_json(f"https://api.modrinth.com/v2/project/{h['project_id']}/version")
            if not vs:
                raise RuntimeError("нет версий")
            f = next((x for x in vs[0]["files"] if x.get("primary")), vs[0]["files"][0])
            tmp = os.path.join(ROOT, "tmp", f["filename"])
            download(f["url"], tmp, force=True)
            return tmp, True
        self._pack_job(getter, h["title"])

    def import_pack(self):
        f = filedialog.askopenfilename(filetypes=[("Modrinth pack", "*.mrpack"), ("Все", "*.*")])
        if f:
            self._pack_job(lambda: (f, False), os.path.splitext(os.path.basename(f))[0])


class InstDialog(tk.Toplevel):
    def __init__(self, app, inst=None):
        super().__init__(app)
        self.app, self.inst = app, inst
        self.configure(bg=BG, padx=28, pady=22)
        self.title("Сборка")
        self.transient(app)
        self.resizable(False, False)
        i = inst or dict(name="Новая сборка", mc=app.latest, loader="Vanilla", ram=4096, jvm="", w=0, h=0, fs=False, server="")
        self.name, self.mc, self.loader = tk.StringVar(value=i["name"]), tk.StringVar(value=i["mc"]), tk.StringVar(value=i["loader"])
        self.ram, self.jvm = tk.IntVar(value=i.get("ram", 4096)), tk.StringVar(value=i.get("jvm", ""))
        self.w, self.h = tk.StringVar(value=str(i.get("w", 0))), tk.StringVar(value=str(i.get("h", 0)))
        self.fs, self.server = tk.BooleanVar(value=i.get("fs", False)), tk.StringVar(value=i.get("server", ""))
        self.snap = tk.BooleanVar(value=False)
        g = tk.Frame(self, bg=BG)
        g.pack()
        r = [0]

        def row(label, widget_fn):
            mklabel(g, label, True, FS).grid(row=r[0], column=0, sticky="nw", pady=7, padx=(0, 18))
            w = widget_fn(g)
            w.grid(row=r[0], column=1, sticky="w", pady=4)
            r[0] += 1
        row("НАЗВАНИЕ", lambda p: mkentry(p, self.name, 30))
        self.vc = ttk.Combobox(g, textvariable=self.mc, state="readonly", width=16, font=F)
        row("ВЕРСИЯ", lambda p: self._ver_row(p))
        row("ЗАГРУЗЧИК", lambda p: ttk.Combobox(p, textvariable=self.loader, values=["Vanilla", "Fabric", "Quilt"],
                                                 state="readonly", width=12, font=F))
        self.ram_lbl = tk.Label(g, bg=BG, fg=FG, font=FB)
        row("ОЗУ", lambda p: self._ram_row(p))
        row("JVM-АРГУМЕНТЫ", lambda p: mkentry(p, self.jvm, 30))
        row("ОКНО (0 = авто)", lambda p: self._win_row(p))
        row("АВТОВХОД НА СЕРВЕР", lambda p: mkentry(p, self.server, 30))
        b = tk.Frame(self, bg=BG)
        b.pack(fill="x", pady=(18, 0))
        mkbtn(b, "СОХРАНИТЬ", self.ok, primary=True).pack(side="left")
        mkbtn(b, "ОТМЕНА", self.destroy).pack(side="left", padx=8)
        if inst:
            mkbtn(b, "УДАЛИТЬ", self.delete).pack(side="right")
        self.fill_versions()
        self.after(60, lambda: dark_title(self))
        self.grab_set()

    def _ver_row(self, p):
        f = tk.Frame(p, bg=BG)
        self.vc = ttk.Combobox(f, textvariable=self.mc, state="readonly", width=16, font=F)
        self.vc.pack(side="left")
        mkcheck(f, "снапшоты", self.snap, self.fill_versions).pack(side="left", padx=10)
        return f

    def _ram_row(self, p):
        f = tk.Frame(p, bg=BG)
        tk.Scale(f, from_=1024, to=16384, resolution=512, orient="horizontal", variable=self.ram, showvalue=False,
                 bg=BG, troughcolor=PANEL, highlightthickness=0, bd=0, sliderrelief="flat", activebackground=ACC,
                 length=260, command=lambda *_: self.ram_lbl_set()).pack(side="left")
        self.ram_lbl = tk.Label(f, bg=BG, fg=FG, font=FB, width=8)
        self.ram_lbl.pack(side="left")
        self.ram_lbl_set()
        return f

    def ram_lbl_set(self):
        self.ram_lbl.config(text=f"{self.ram.get() / 1024:.1f} GB")

    def _win_row(self, p):
        f = tk.Frame(p, bg=BG)
        mkentry(f, self.w, 6).pack(side="left", ipady=3)
        tk.Label(f, text=" × ", bg=BG, fg=DIM, font=F).pack(side="left")
        mkentry(f, self.h, 6).pack(side="left", ipady=3)
        mkcheck(f, "полный экран", self.fs).pack(side="left", padx=12)
        return f

    def fill_versions(self):
        ids = self.app.version_ids(self.snap.get())
        if self.mc.get() and self.mc.get() not in ids:
            ids.insert(0, self.mc.get())
        self.vc["values"] = ids

    def ok(self):
        name = self.name.get().strip()
        if not name or not self.mc.get():
            messagebox.showwarning(APP, "Укажи название и версию", parent=self)
            return
        try:
            w, h = int(self.w.get() or 0), int(self.h.get() or 0)
        except ValueError:
            messagebox.showwarning(APP, "Размер окна — числа", parent=self)
            return
        data = dict(name=name, mc=self.mc.get(), loader=self.loader.get(), ram=self.ram.get(), jvm=self.jvm.get().strip(),
                    w=w, h=h, fs=self.fs.get(), server=self.server.get().strip())
        if self.inst:
            self.inst.update(data)
        else:
            iid = new_id(name)
            self.app.add_instance(dict(data, dir=iid), save=False)
        self.app.save()
        self.app.refresh_inst()
        self.destroy()

    def delete(self):
        if len(self.app.cfg["instances"]) <= 1:
            messagebox.showinfo(APP, "Нельзя удалить последнюю сборку", parent=self)
            return
        if not messagebox.askyesno(APP, f"Удалить сборку «{self.inst['name']}»?", parent=self):
            return
        if messagebox.askyesno(APP, "Удалить и папку с мирами, модами и настройками?", parent=self):
            shutil.rmtree(os.path.join(INST, self.inst["dir"]), ignore_errors=True)
        self.app.cfg["instances"].remove(self.inst)
        self.app.cfg["selected"] = self.app.cfg["instances"][0]["id"]
        self.app.save()
        self.app.refresh_inst()
        self.destroy()


class App(tk.Tk):
    def __init__(self):
        super().__init__()
        if IS_WIN:
            try:
                import ctypes
                ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID("seed.launcher.app")
            except Exception:
                pass
        os.makedirs(ROOT, exist_ok=True)
        self.title(APP)
        self.geometry("1060x740")
        self.minsize(960, 680)
        self.cfg = load_cfg()
        self.versions, self.latest, self.running = [], "", False
        self._migrate()
        apply_theme(self.cfg)
        self.configure(bg=BG)
        self._ico = None
        try:
            self.iconbitmap(default=res("seed.ico"))
        except Exception:
            pass
        try:
            self._ico = tk.PhotoImage(file=res("icon.png"))
            self.iconphoto(True, self._ico)
        except Exception:
            pass
        self.cur_page = "play"
        self.build_ui()
        self.show("play")
        threading.Thread(target=self.load_versions, daemon=True).start()
        self.after(60, lambda: dark_title(self))
        self.protocol("WM_DELETE_WINDOW", self.on_close)

    def _migrate(self):
        c = self.cfg
        if "instances" not in c:
            mc, loader = c.get("version", ""), c.get("loader", "Vanilla")
            d = f"{mc}-{loader.lower()}" if mc else new_id("main")
            c["instances"] = [dict(id=d, dir=d, name="Основная", mc=mc, loader=loader, ram=c.get("ram", 4096), jvm="",
                                   w=0, h=0, fs=False, server="", played=0)]
            c["selected"] = d
        c.setdefault("nick", "Player")
        c.setdefault("after", "keep")

    # ── общее ──
    def ui(self, fn, *a):
        try:
            self.after(0, fn, *a)
        except Exception:
            pass

    def save(self):
        try:
            if hasattr(self, "nick"):
                self.cfg["nick"] = self.nick.get()
            save_cfg(self.cfg)
        except Exception:
            pass

    def cur(self):
        for i in self.cfg["instances"]:
            if i["id"] == self.cfg.get("selected"):
                return i
        return self.cfg["instances"][0]

    def profile(self):
        i = self.cur()
        return i["mc"] or "unknown", i["loader"], os.path.join(INST, i["dir"])

    def add_instance(self, inst, save=True):
        base = dict(ram=4096, jvm="", w=0, h=0, fs=False, server="", played=0)
        base.update(inst)
        base["id"] = base["dir"]
        self.cfg["instances"].append(base)
        self.cfg["selected"] = base["id"]
        if save:
            self.save()
            self.refresh_inst()

    def version_ids(self, snaps=False):
        return [v["id"] for v in self.versions
                if (v["type"] == "release" and v["releaseTime"] >= "2013-10-01") or (snaps and v["type"] == "snapshot")]

    def load_versions(self):
        m = None
        try:
            m = http_json(MANIFEST)
            with open(MAN_CACHE, "w") as f:
                json.dump(m, f)
        except Exception:
            try:
                with open(MAN_CACHE) as f:
                    m = json.load(f)
            except Exception:
                pass
        if m:
            self.versions, self.latest = m["versions"], m["latest"]["release"]
            for i in self.cfg["instances"]:
                if not i["mc"]:
                    i["mc"] = self.latest
        self.ui(self.after_versions)

    def after_versions(self):
        if not self.versions:
            self.status.set("Нет связи с сервером версий. Проверь интернет.")
        self.refresh_inst()

    def setup_style(self):
        s = ttk.Style(self)
        s.theme_use("clam")
        s.configure("TCombobox", fieldbackground=PANEL, background=PANEL, foreground=FG, arrowcolor=ACC,
                    bordercolor=LINE, lightcolor=PANEL, darkcolor=PANEL, selectbackground=PANEL,
                    selectforeground=FG, padding=5)
        s.map("TCombobox", fieldbackground=[("readonly", PANEL)], foreground=[("readonly", FG)],
              bordercolor=[("focus", ACC)])
        s.configure("Seed.Horizontal.TProgressbar", troughcolor=PANEL, background=ACC, bordercolor=BG,
                    lightcolor=ACC, darkcolor=ACC, thickness=4)
        for k, v in (("background", PANEL), ("foreground", FG), ("selectBackground", ACC),
                     ("selectForeground", ACC_TXT)):
            self.option_add(f"*TCombobox*Listbox.{k}", v)
        self.option_add("*TCombobox*Listbox.font", F)

    def rebuild(self, page):
        log = self.logbox.get("1.0", "end") if hasattr(self, "logbox") else ""
        self.save()
        for w in self.winfo_children():
            w.destroy()
        apply_theme(self.cfg)
        self.configure(bg=BG)
        self.build_ui()
        self.logbox.insert("end", log)
        self.show(page)
        self.after(60, lambda: dark_title(self))

    # ── каркас ──
    def build_ui(self):
        self.setup_style()
        self.build_sidebar()
        self.main = tk.Frame(self, bg=BG)
        self.main.pack(side="left", fill="both", expand=True)
        self.pages = {}
        self.build_play()
        self.build_instances()
        self.pages["mods"] = ContentPage(self, self.main, "mod", "mod", "mods", "МОДЫ",
                                         "Каталог Modrinth · зависимости ставятся сами")
        self.pages["packs"] = ContentPage(self, self.main, "pack", "resourcepack", "resourcepacks", "РЕСУРСПАКИ",
                                          "Текстуры и оформление")
        self.pages["shaders"] = ContentPage(self, self.main, "shader", "shader", "shaderpacks", "ШЕЙДЕРЫ",
                                            "Нужен Iris (мод для Fabric) или OptiFine")
        self.pages["modpacks"] = ContentPage(self, self.main, "modpack", "modpack", "", "МОДПАКИ",
                                             "Готовые сборки Modrinth — ставятся как новая сборка одним кликом")
        self.build_servers()
        self.build_skin()
        self.build_look()
        self.build_settings()
        self.refresh_inst()

    def build_sidebar(self):
        sb = tk.Frame(self, bg=BG, width=220)
        sb.pack(side="left", fill="y")
        sb.pack_propagate(False)
        tk.Frame(self, bg=LINE, width=1).pack(side="left", fill="y")
        top = tk.Frame(sb, bg=BG)
        top.pack(fill="x", padx=22, pady=(24, 22))
        cv = tk.Canvas(top, width=44, height=44, bg=BG, highlightthickness=0)
        cv.pack(anchor="w")
        draw_logo(cv, 44, ACC)
        tk.Label(top, text="S E E D", font=(F[0], 16, "bold"), bg=BG, fg=FG).pack(anchor="w", pady=(10, 0))
        tk.Label(top, text="L A U N C H E R", font=(F[0], 8), bg=BG, fg=DIM).pack(anchor="w")
        self.nav = {}
        items = [("play", "ИГРА"), ("instances", "СБОРКИ"), ("mods", "МОДЫ"), ("packs", "РЕСУРСПАКИ"),
                 ("shaders", "ШЕЙДЕРЫ"), ("modpacks", "МОДПАКИ"), ("servers", "СЕРВЕРА"), ("skin", "СКИН"), ("look", "ВНЕШНИЙ ВИД"),
                 ("settings", "НАСТРОЙКИ")]
        for i, (key, name) in enumerate(items, 1):
            row = tk.Frame(sb, bg=BG, cursor="hand2")
            row.pack(fill="x")
            bar = tk.Frame(row, bg=BG, width=3)
            bar.pack(side="left", fill="y")
            lb = tk.Label(row, text=f"{i:02d}  {name}", font=FB, bg=BG, fg=DIM, anchor="w", padx=19, pady=7)
            lb.pack(side="left", fill="x", expand=True)
            for w in (row, lb, bar):
                w.bind("<Button-1>", lambda e, k=key: self.show(k))
            lb.bind("<Enter>", lambda e, l=lb: l.config(fg=FG))
            lb.bind("<Leave>", lambda e, l=lb, k=key: l.config(fg=FG if self.cur_page == k else DIM))
            self.nav[key] = (bar, lb)
        tk.Label(sb, text=f"v{VER}", font=FS, bg=BG, fg=DIM).pack(side="bottom", anchor="w", padx=22, pady=14)

    def show(self, key):
        self.cur_page = key
        for p in self.pages.values():
            p.pack_forget()
        self.pages[key].pack(fill="both", expand=True)
        for k, (bar, lb) in self.nav.items():
            bar.config(bg=ACC if k == key else BG)
            lb.config(fg=FG if k == key else DIM)
        if hasattr(self.pages[key], "on_show"):
            self.pages[key].on_show()

    # ── ИГРА ──
    def build_play(self):
        p = tk.Frame(self.main, bg=BG, padx=36, pady=28)
        self.pages["play"] = p
        header(p, "ИГРА", "Minecraft Java Edition · офлайн-режим")
        self.nick = tk.StringVar(value=self.cfg.get("nick", "Player"))
        self.inst_var = tk.StringVar()
        g = tk.Frame(p, bg=BG)
        g.pack(fill="x", pady=(20, 0))
        mklabel(g, "НИКНЕЙМ", True, FS).grid(row=0, column=0, sticky="w")
        mklabel(g, "СБОРКА", True, FS).grid(row=0, column=1, sticky="w", padx=(18, 0))
        mkentry(g, self.nick, 20).grid(row=1, column=0, sticky="w", pady=(4, 0), ipady=5)
        self.icombo = ttk.Combobox(g, textvariable=self.inst_var, state="readonly", width=28, font=F)
        self.icombo.grid(row=1, column=1, sticky="w", padx=(18, 0), pady=(4, 0))
        self.icombo.bind("<<ComboboxSelected>>", self.on_pick)
        bb = tk.Frame(g, bg=BG)
        bb.grid(row=1, column=2, padx=(10, 0), pady=(4, 0))
        mkbtn(bb, "＋", lambda: InstDialog(self), pady=4, padx=10).pack(side="left")
        mkbtn(bb, "⚙", lambda: InstDialog(self, self.cur()), pady=4, padx=10).pack(side="left", padx=6)
        self.info = tk.StringVar()
        tk.Label(p, textvariable=self.info, font=FS, bg=BG, fg=DIM, anchor="w").pack(fill="x", pady=(14, 0))
        self.play_btn = mkbtn(p, "▶   З А П У С Т И Т Ь", self.play, primary=True, padx=44, pady=15)
        self.play_btn.pack(anchor="w", pady=(18, 14))
        self.prog = ttk.Progressbar(p, style="Seed.Horizontal.TProgressbar", mode="determinate", maximum=100)
        self.prog.pack(fill="x")
        self.status = tk.StringVar(value="Готов к запуску")
        tk.Label(p, textvariable=self.status, font=FS, bg=BG, fg=DIM, anchor="w").pack(fill="x", pady=(6, 8))
        self.logbox = tk.Text(p, height=8, font=FS, bg=PANEL, fg=DIM, bd=0, relief="flat",
                              highlightthickness=1, highlightbackground=LINE, wrap="none")
        self.logbox.pack(fill="both", expand=True)
        r = tk.Frame(p, bg=BG)
        r.pack(anchor="w", pady=(10, 0))
        mkbtn(r, "ПАПКА ИГРЫ", lambda: open_path(self.profile()[2])).pack(side="left")
        mkbtn(r, "БЭКАП МИРОВ", self.backup).pack(side="left", padx=8)
        if self.running:
            self.play_btn.config(state="disabled")

    def refresh_inst(self):
        if not hasattr(self, "icombo"):
            return
        ins = self.cfg["instances"]
        self.icombo["values"] = [i["name"] for i in ins]
        c = self.cur()
        self.inst_var.set(c["name"])
        self.info.set(f"{c['mc']} · {c['loader']} · {c['ram'] / 1024:.1f} GB · наиграно {fmt_time(c.get('played', 0))}"
                      + (f" · автовход {c['server']}" if c.get("server") else ""))
        if hasattr(self, "ilist"):
            self.ilist.delete(0, "end")
            for i in ins:
                mark = "▸ " if i["id"] == c["id"] else "  "
                self.ilist.insert("end", f"{mark}{i['name'][:26]:<28}{i['mc']:<10}{i['loader']:<9}{fmt_time(i.get('played', 0))}")

    def on_pick(self, *_):
        self.cfg["selected"] = self.cfg["instances"][self.icombo.current()]["id"]
        self.save()
        self.refresh_inst()

    def log(self, s):
        self.logbox.insert("end", s + "\n")
        self.logbox.see("end")
        if int(self.logbox.index("end-1c").split(".")[0]) > 2000:
            self.logbox.delete("1.0", "500.0")

    def set_prog(self, d, t):
        self.prog["value"] = d * 100 / max(t, 1)
        self.status.set(f"Загрузка файлов… {d}/{t}")

    def set_playing(self, on):
        self.running = on
        self.play_btn.config(state="disabled" if on else "normal", text="…  З А П У С К" if on else "▶   З А П У С Т И Т Ь")
        if not on:
            self.prog["value"] = 0

    def play(self, server=None):
        if self.running:
            return
        nick = re.sub(r"[^A-Za-z0-9_]", "", self.nick.get())[:16]
        if len(nick) < 3:
            messagebox.showwarning(APP, "Ник: 3–16 символов, латиница, цифры и _")
            return
        inst = self.cur()
        if not inst["mc"]:
            messagebox.showwarning(APP, "Версии ещё не загружены")
            return
        self.nick.set(nick)
        self.save()
        self.set_playing(True)
        threading.Thread(target=self.run_game, args=(inst, nick, server), daemon=True).start()

    def run_game(self, inst, nick, server=None):
        st = lambda s: self.ui(self.status.set, s)
        if server:
            inst = dict(inst, server=server)
        gamedir = os.path.join(INST, inst["dir"])
        skin_srv = None
        try:
            st("Получение данных версии…")
            vid = install_loader(inst["mc"], inst["loader"]) if inst["loader"] in LOADERS else inst["mc"]
            v = load_version(vid)
            os.makedirs(gamedir, exist_ok=True)
            cp, nd, assets_dir = prepare(v, gamedir, lambda d, t: self.ui(self.set_prog, d, t))
            major = v.get("javaVersion", {}).get("majorVersion", 8)
            java = ensure_java(major, self.cfg.get("java", ""), st)
            agent = []
            if os.path.exists(SKIN) and self.cfg.get("skin_mode", "auto") == "auto":
                st("Подготовка модуля скинов…")
                jar = ensure_injector()
                if jar:
                    with open(SKIN, "rb") as f:
                        skin_srv = SkinServer(f.read(), nick, bool(self.cfg.get("slim")))
                    agent = [f"-javaagent:{jar}=http://127.0.0.1:{skin_srv.port}"]
                    remove_skin_pack(gamedir)
                else:
                    self.ui(self.log, "! не удалось скачать модуль скинов — использую ресурспак")
                    apply_skin(gamedir)
            else:
                apply_skin(gamedir)
            cmd = build_cmd(v, java, gamedir, nick, inst, cp, nd, assets_dir, agent)
            self.ui(self.prog.config, {"value": 100})
            st("Игра запущена")
            self.ui(self.log, "> запуск " + vid)
            if self.cfg.get("after") == "hide":
                self.ui(self.iconify)
            t0 = time.time()
            proc = subprocess.Popen(cmd, cwd=gamedir, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True,
                                    encoding="utf-8", errors="replace", creationflags=0x08000000 if IS_WIN else 0)
            for line in proc.stdout:
                self.ui(self.log, line.rstrip())
            code = proc.wait()
            self.ui(self.add_played, inst["id"], time.time() - t0)
            st("Игра закрыта" if code == 0 else f"Игра завершилась с кодом {code} — смотри лог")
        except Exception as e:
            st("Ошибка: " + str(e)[:90])
            self.ui(self.log, traceback.format_exc())
        finally:
            if skin_srv:
                skin_srv.stop()
            self.ui(self.set_playing, False)
            if self.cfg.get("after") == "hide":
                self.ui(self.deiconify)

    def add_played(self, iid, secs):
        for i in self.cfg["instances"]:
            if i["id"] == iid:
                i["played"] = i.get("played", 0) + int(secs)
        self.save()
        self.refresh_inst()

    def backup(self):
        saves = os.path.join(self.profile()[2], "saves")
        if not os.path.isdir(saves) or not os.listdir(saves):
            messagebox.showinfo(APP, "В этой сборке пока нет миров")
            return
        name = re.sub(r"[^\w\-]+", "_", self.cur()["name"]) + time.strftime("_%Y-%m-%d_%H-%M")
        self.status.set("Создаю бэкап…")

        def work():
            try:
                os.makedirs(BACKUPS, exist_ok=True)
                shutil.make_archive(os.path.join(BACKUPS, name), "zip", saves)
                self.ui(self.status.set, "Бэкап сохранён: " + name + ".zip")
                self.ui(open_path, BACKUPS)
            except Exception as e:
                self.ui(self.status.set, "Ошибка бэкапа: " + str(e)[:60])
        threading.Thread(target=work, daemon=True).start()

    # ── СБОРКИ ──
    def build_instances(self):
        p = tk.Frame(self.main, bg=BG, padx=36, pady=28)
        self.pages["instances"] = p
        header(p, "СБОРКИ", "У каждой сборки свои моды, миры, ОЗУ и настройки")
        tk.Label(p, text=f"{'  название':<30}{'версия':<10}{'загрузчик':<9}время", font=FS, bg=BG, fg=DIM,
                 anchor="w").pack(fill="x", pady=(16, 4))
        self.ilist = mklist(p, 12)
        self.ilist.pack(fill="both", expand=True)
        self.ilist.bind("<Double-Button-1>", lambda e: self.pick_from_list(go=True))
        r = tk.Frame(p, bg=BG)
        r.pack(anchor="w", pady=10)
        mkbtn(r, "ВЫБРАТЬ", self.pick_from_list, primary=True).pack(side="left")
        mkbtn(r, "НОВАЯ", lambda: InstDialog(self)).pack(side="left", padx=8)
        mkbtn(r, "ИЗМЕНИТЬ", self.edit_from_list).pack(side="left")
        mkbtn(r, "ПАПКА", lambda: open_path(os.path.join(INST, self.cfg["instances"][self._sel()]["dir"]))).pack(side="left", padx=8)

    def _sel(self):
        s = self.ilist.curselection()
        return s[0] if s else self.cfg["instances"].index(self.cur())

    def pick_from_list(self, go=False):
        self.cfg["selected"] = self.cfg["instances"][self._sel()]["id"]
        self.save()
        self.refresh_inst()
        if go:
            self.show("play")

    def edit_from_list(self):
        InstDialog(self, self.cfg["instances"][self._sel()])


    # ── СЕРВЕРА ──
    def build_servers(self):
        p = tk.Frame(self.main, bg=BG, padx=36, pady=28)
        self.pages["servers"] = p
        p.on_show = self.servers_refresh
        self.sstat = getattr(self, "sstat", {})
        header(p, "СЕРВЕРА", "Свой список · онлайн и пинг · вход в один клик")
        tk.Label(p, text=f"{'  название':<24}{'адрес':<27}{'онлайн':<11}{'пинг':<8}версия", font=FS, bg=BG, fg=DIM,
                 anchor="w").pack(fill="x", pady=(16, 4))
        self.slist = mklist(p, 11)
        self.slist.pack(fill="both", expand=True)
        self.slist.bind("<Double-Button-1>", lambda e: self.server_join())
        r = tk.Frame(p, bg=BG)
        r.pack(anchor="w", pady=10)
        mkbtn(r, "ЗАЙТИ", self.server_join, primary=True).pack(side="left")
        mkbtn(r, "ДОБАВИТЬ", self.server_add).pack(side="left", padx=8)
        mkbtn(r, "УДАЛИТЬ", self.server_del).pack(side="left")
        mkbtn(r, "ОБНОВИТЬ", self.servers_refresh).pack(side="left", padx=8)
        mkbtn(r, "СБОРКА ПОД ВЕРСИЮ СЕРВЕРА", self.server_make_inst).pack(side="left")
        self.smsg = tk.StringVar()
        tk.Label(p, textvariable=self.smsg, font=FS, bg=BG, fg=DIM, anchor="w").pack(fill="x")
        tk.Label(p, text="Работают серверы в офлайн-режиме (online-mode=false). Адрес вводи как play.example.com "
                         "или 1.2.3.4:25565.", font=FS, bg=BG, fg=DIM, anchor="w").pack(fill="x", pady=(6, 0))

    def servers_render(self):
        try:
            sel = self.slist.curselection()
            self.slist.delete(0, "end")
            for sv in self.cfg.get("servers", []):
                st = self.sstat.get(sv["addr"], "wait")
                if st == "wait":
                    tail = "…"
                elif st is None:
                    tail = f"{'—':<11}{'—':<8}офлайн/нет ответа"
                else:
                    motd, on, mx, ver, ms = st
                    tail = f"{f'{on}/{mx}':<11}{f'{ms} мс':<8}{ver[:22]}"
                self.slist.insert("end", f"  {sv['name'][:21]:<24}{sv['addr'][:24]:<27}{tail}")
            if sel:
                self.slist.selection_set(sel[0])
        except tk.TclError:
            pass

    def servers_refresh(self):
        self.cfg.setdefault("servers", [])
        for sv in self.cfg["servers"]:
            self.sstat[sv["addr"]] = "wait"
            threading.Thread(target=self._ping, args=(sv["addr"],), daemon=True).start()
        self.servers_render()

    def _ping(self, addr):
        try:
            res = ping_server(addr)
        except Exception:
            res = None
        self.sstat[addr] = res
        self.ui(self.servers_render)

    def _ssel(self):
        s = self.slist.curselection()
        if not s:
            self.smsg.set("Выбери сервер в списке")
            return None
        return self.cfg["servers"][s[0]]

    def server_add(self):
        d = tk.Toplevel(self)
        d.configure(bg=BG, padx=26, pady=22)
        d.title("Добавить сервер")
        d.transient(self)
        d.resizable(False, False)
        nm, ad = tk.StringVar(), tk.StringVar()
        mklabel(d, "НАЗВАНИЕ", True, FS).pack(anchor="w")
        mkentry(d, nm, 34).pack(ipady=5, pady=(4, 12))
        mklabel(d, "АДРЕС (ip или домен[:порт])", True, FS).pack(anchor="w")
        e = mkentry(d, ad, 34)
        e.pack(ipady=5, pady=(4, 16))

        def ok():
            a = ad.get().strip().lower()
            if not a:
                return
            self.cfg.setdefault("servers", []).append({"name": nm.get().strip() or a, "addr": a})
            self.save()
            d.destroy()
            self.servers_refresh()
        e.bind("<Return>", lambda ev: ok())
        mkbtn(d, "ДОБАВИТЬ", ok, primary=True).pack(anchor="w")
        d.after(60, lambda: dark_title(d))
        d.grab_set()

    def server_del(self):
        sv = self._ssel()
        if sv:
            self.cfg["servers"].remove(sv)
            self.save()
            self.servers_render()

    @staticmethod
    def _ver_of(stat):
        if not stat or stat == "wait":
            return None
        m = re.findall(r"\d+\.\d+(?:\.\d+)?", stat[3])
        return m[-1] if m else None

    def server_join(self):
        sv = self._ssel()
        if not sv:
            return
        v, inst = self._ver_of(self.sstat.get(sv["addr"])), self.cur()
        if v and v != inst["mc"] and not inst["mc"].startswith(v + "."):
            if not messagebox.askyesno(APP, f"Сервер на {v}, а выбранная сборка — {inst['mc']}.\n"
                                            "Скорее всего не зайдёт. Всё равно запустить?"):
                return
        self.show("play")
        self.play(server=sv["addr"])

    def server_make_inst(self):
        sv = self._ssel()
        if not sv:
            return
        v = self._ver_of(self.sstat.get(sv["addr"]))
        if not v or v not in self.version_ids(True):
            self.smsg.set("Не удалось определить версию сервера (нет ответа?). Создай сборку вручную во вкладке СБОРКИ.")
            return
        self.add_instance({"name": sv["name"], "mc": v, "loader": "Vanilla", "dir": new_id(sv["name"])})
        self.smsg.set(f"Создана сборка «{sv['name']}» ({v}) и выбрана. Жми ЗАЙТИ.")

    # ── СКИН ──
    def build_skin(self):
        p = tk.Frame(self.main, bg=BG, padx=36, pady=28)
        self.pages["skin"] = p
        header(p, "СКИН", "Загрузил — и он в игре. Без ресурспаков")
        body = tk.Frame(p, bg=BG)
        body.pack(fill="x", pady=(24, 0))
        self.skin_prev = tk.Label(body, bg=PANEL, width=10, height=5, text="нет\nскина", font=FS, fg=DIM,
                                  highlightthickness=1, highlightbackground=LINE)
        self.skin_prev.pack(side="left", anchor="n")
        side = tk.Frame(body, bg=BG)
        side.pack(side="left", padx=28, anchor="n")
        mkbtn(side, "ВЫБРАТЬ PNG…", self.skin_file, primary=True).pack(anchor="w")
        mklabel(side, "или взять скин существующего игрока по нику:", True, FS).pack(anchor="w", pady=(22, 6))
        r = tk.Frame(side, bg=BG)
        r.pack(anchor="w")
        self.skin_nick = tk.StringVar()
        mkentry(r, self.skin_nick, 18).pack(side="left", ipady=5)
        mkbtn(r, "ЗАГРУЗИТЬ", self.skin_nick_go).pack(side="left", padx=8)
        self.slim_v = tk.BooleanVar(value=bool(self.cfg.get("slim")))
        mkcheck(side, "тонкие руки (модель Alex)", self.slim_v,
                lambda: (self.cfg.__setitem__("slim", self.slim_v.get()), self.save())).pack(anchor="w", pady=(20, 0))
        mklabel(side, "СПОСОБ ПРИМЕНЕНИЯ", True, FS).pack(anchor="w", pady=(16, 4))
        self.mode_v = tk.StringVar(value="Ресурспаком (запасной)" if self.cfg.get("skin_mode") == "pack" else "Автоматически")
        mc = ttk.Combobox(side, textvariable=self.mode_v, state="readonly", width=26, font=F,
                          values=["Автоматически", "Ресурспаком (запасной)"])
        mc.pack(anchor="w")
        mc.bind("<<ComboboxSelected>>", lambda e: (self.cfg.__setitem__("skin_mode", "pack" if mc.current() == 1 else "auto"), self.save()))
        mkbtn(side, "СБРОСИТЬ СКИН", self.skin_reset).pack(anchor="w", pady=(22, 0))
        self.skin_msg = tk.StringVar()
        tk.Label(p, textvariable=self.skin_msg, font=FS, bg=BG, fg=DIM, anchor="w").pack(fill="x", pady=(20, 0))
        tk.Label(p, text="Загрузил PNG — и скин сразу в игре, ничего включать не нужно.\n"
                         "Работает на любых сборках. Другие игроки видят его только если у них тоже Seed Launcher\n"
                         "с таким же скином. Формат PNG 64×64 (или 64×32).", font=FS, bg=BG, fg=DIM, justify="left",
                 anchor="w").pack(fill="x", pady=(10, 0))
        self.skin_preview()

    def skin_preview(self):
        if not os.path.exists(SKIN):
            self.skin_prev.config(image="", text="нет\nскина", width=10, height=5)
            return
        try:
            img = tk.PhotoImage(file=SKIN)
            head = tk.PhotoImage(width=80, height=80)
            head.tk.call(str(head), "copy", str(img), "-from", 8, 8, 16, 16, "-zoom", 10, 10)
            self._head, self._skin_img = head, img
            self.skin_prev.config(image=head, text="", width=80, height=80)
        except Exception:
            self.skin_prev.config(image="", text="скин\nустановлен", width=10, height=5)

    def skin_file(self):
        f = filedialog.askopenfilename(filetypes=[("PNG", "*.png")])
        if not f:
            return
        try:
            w, h = png_size(f)
            if w != 64 or h not in (32, 64):
                raise ValueError(f"Нужен 64×64 или 64×32, а тут {w}×{h}")
            shutil.copy(f, SKIN)
            self.skin_msg.set("Скин установлен. Запусти игру.")
            self.skin_preview()
        except Exception as e:
            self.skin_msg.set("Ошибка: " + str(e))

    def skin_nick_go(self):
        n = self.skin_nick.get().strip()
        if not n:
            return
        self.skin_msg.set("загрузка…")

        def work():
            try:
                fetch_skin_by_nick(n)
                self.ui(self.skin_msg.set, f"Скин игрока {n} установлен. Запусти игру.")
                self.ui(self.skin_preview)
            except Exception as e:
                self.ui(self.skin_msg.set, "Ошибка: " + str(e)[:80])
        threading.Thread(target=work, daemon=True).start()

    def skin_reset(self):
        if os.path.exists(SKIN):
            os.remove(SKIN)
        self.skin_msg.set("Скин сброшен (применится при следующем запуске).")
        self.skin_preview()

    # ── ВНЕШНИЙ ВИД ──
    def build_look(self):
        p = tk.Frame(self.main, bg=BG, padx=36, pady=28)
        self.pages["look"] = p
        header(p, "ВНЕШНИЙ ВИД", "Тема, цвет акцента, шрифт — применяется сразу")
        mklabel(p, "ТЕМА", True, FS).pack(fill="x", pady=(18, 8))
        grid = tk.Frame(p, bg=BG)
        grid.pack(fill="x")
        for n, (i, t) in enumerate(THEMES.items()):
            card = tk.Frame(grid, bg=t[0], width=118, height=64, highlightthickness=2,
                            highlightbackground=ACC if self.cfg.get("theme", "Mono") == i else LINE, cursor="hand2")
            card.grid(row=n // 4, column=n % 4, padx=(0, 10), pady=(0, 10))
            card.pack_propagate(False)
            tk.Label(card, text=i.upper(), font=(F[0], 9, "bold"), bg=t[0], fg=t[2]).pack(anchor="w", padx=8, pady=(8, 0))
            sw = tk.Frame(card, bg=t[0])
            sw.pack(anchor="w", padx=8, pady=6)
            for c in (t[5], t[3], t[4]):
                tk.Frame(sw, bg=c, width=18, height=10).pack(side="left", padx=(0, 3))
            for w in (card, *card.winfo_children(), sw):
                w.bind("<Button-1>", lambda e, k=i: self.set_theme(k))
        r = tk.Frame(p, bg=BG)
        r.pack(anchor="w", pady=(10, 0))
        mkbtn(r, "СВОЙ ЦВЕТ АКЦЕНТА…", self.pick_accent).pack(side="left")
        mkbtn(r, "СБРОСИТЬ АКЦЕНТ", self.reset_accent).pack(side="left", padx=8)
        mklabel(p, "ШРИФТ", True, FS).pack(fill="x", pady=(24, 6))
        f = tk.Frame(p, bg=BG)
        f.pack(anchor="w")
        fams = sorted({x for x in tkfont.families() if not x.startswith("@")})
        self.font_v, self.size_v = tk.StringVar(value=F[0]), tk.StringVar(value=str(F[1]))
        ttk.Combobox(f, textvariable=self.font_v, values=fams, state="readonly", width=26, font=F).pack(side="left")
        ttk.Combobox(f, textvariable=self.size_v, values=["9", "10", "11", "12", "13"], state="readonly", width=4,
                     font=F).pack(side="left", padx=8)
        mkbtn(f, "ПРИМЕНИТЬ", self.set_font, primary=True).pack(side="left")
        tk.Label(p, text="Подсказка: хорошо выглядят моноширинные шрифты — Consolas, Cascadia Mono, Courier New.",
                 font=FS, bg=BG, fg=DIM, anchor="w").pack(fill="x", pady=(12, 0))

    def set_theme(self, name):
        self.cfg["theme"], self.cfg["accent"] = name, None
        self.after(10, lambda: self.rebuild("look"))

    def pick_accent(self):
        c = colorchooser.askcolor(color=ACC, title="Цвет акцента")[1]
        if c:
            self.cfg["accent"] = c
            self.after(10, lambda: self.rebuild("look"))

    def reset_accent(self):
        self.cfg["accent"] = None
        self.after(10, lambda: self.rebuild("look"))

    def set_font(self):
        self.cfg["font"], self.cfg["fsize"] = self.font_v.get(), int(self.size_v.get())
        self.after(10, lambda: self.rebuild("look"))

    # ── НАСТРОЙКИ ──
    def build_settings(self):
        p = tk.Frame(self.main, bg=BG, padx=36, pady=28)
        self.pages["settings"] = p
        header(p, "НАСТРОЙКИ", "")
        mklabel(p, "ПУТЬ К JAVA (пусто = автоматически)", True, FS).pack(fill="x", pady=(22, 4))
        r = tk.Frame(p, bg=BG)
        r.pack(fill="x")
        self.java = tk.StringVar(value=self.cfg.get("java", ""))
        mkentry(r, self.java, 52).pack(side="left", ipady=5)
        mkbtn(r, "ОБЗОР", self.pick_java).pack(side="left", padx=8)
        mkbtn(r, "СОХРАНИТЬ", self.save_java, primary=True).pack(side="left")
        mklabel(p, "ПОСЛЕ ЗАПУСКА ИГРЫ", True, FS).pack(fill="x", pady=(24, 4))
        self.after_v = tk.StringVar(value="Свернуть лаунчер на время игры" if self.cfg.get("after") == "hide" else "Оставить открытым")
        cb = ttk.Combobox(p, textvariable=self.after_v, state="readonly", width=34, font=F,
                          values=["Оставить открытым", "Свернуть лаунчер на время игры"])
        cb.pack(anchor="w")
        cb.bind("<<ComboboxSelected>>", lambda e: (self.cfg.__setitem__("after", "hide" if cb.current() == 1 else "keep"), self.save()))
        mklabel(p, "ДАННЫЕ ЛАУНЧЕРА", True, FS).pack(fill="x", pady=(24, 4))
        mklabel(p, ROOT).pack(fill="x")
        rr = tk.Frame(p, bg=BG)
        rr.pack(anchor="w", pady=(8, 0))
        mkbtn(rr, "ОТКРЫТЬ ПАПКУ", lambda: open_path(ROOT)).pack(side="left")
        mkbtn(rr, "ПАПКА БЭКАПОВ", lambda: open_path(BACKUPS)).pack(side="left", padx=8)

    def pick_java(self):
        f = filedialog.askopenfilename(filetypes=[("java", "java.exe javaw.exe java"), ("Все", "*.*")])
        if f:
            self.java.set(f)

    def save_java(self):
        self.cfg["java"] = self.java.get().strip()
        save_cfg(self.cfg)
        messagebox.showinfo(APP, "Сохранено")

    def on_close(self):
        self.save()
        self.destroy()


if __name__ == "__main__":
    App().mainloop()
